import Image from 'next/image';

export default function Home() {
  return (
    <div>
      <div className="container mx-auto">
        {/* <div className="flex justify-center py-20">
          <Image src={"/MainLogo.svg"} alt="MainLogo" width={334} height={56} />
        </div> */}
      </div>
    </div>
  );
}

import React from "react";
import Select from "react-select";

export const MultipleSelectBox = ({
  form,
  name,
  field,
  style,
  value,
  options,
  isMulti = false,
  className,
  onKeyDown,
  placeholder,
  components,
}: any) => {
  const onChange = (option: any) => form.setFieldValue(name, option);
  return (
    <Select
      name={name}
      value={value}
      styles={style}
      options={options}
      isMulti={isMulti}
      onChange={onChange}
      className={className}
      components={components}
      placeholder={placeholder}
      controlShouldRenderValue={false}
      onKeyDown={(e) => onKeyDown(e?.target?.value)}
    />
  );
};

export default MultipleSelectBox;
